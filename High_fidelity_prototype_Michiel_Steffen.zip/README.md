# High_fidelity_prototype_Michiel_Steffen

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```
