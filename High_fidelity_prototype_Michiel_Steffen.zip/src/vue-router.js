// import Login from './components/Login.vue'

// const routes = [
//     { path: '/login', component: Login },
    
//   ]


//   const router = new VueRouter({
//     routes // short for `routes: routes`
//   })